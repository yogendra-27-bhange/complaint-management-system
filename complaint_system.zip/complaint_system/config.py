# config.py
host = 'localhost'
user = 'root'
password = 'root0808'
database = 'complaint_db'
